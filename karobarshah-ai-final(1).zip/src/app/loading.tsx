import { Spinner } from "@/components/ui/spinner";

export default function Loading() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-paper">
      <Spinner size="lg" className="text-ledger" />
    </div>
  );
}
