import "server-only";
import { z } from "zod";

const serverEnvSchema = z.object({
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(1, { error: "SUPABASE_SERVICE_ROLE_KEY is required for server-only admin operations." }),
  AI_PROVIDER: z.enum(["mock", "openai", "anthropic"]).default("mock"),
  OPENAI_API_KEY: z.string().min(1).optional(),
  OPENAI_BASE_URL: z.url().default("https://api.openai.com/v1"),
  ANTHROPIC_API_KEY: z.string().min(1).optional(),
  ANTHROPIC_BASE_URL: z.url().default("https://api.anthropic.com/v1"),
  WHATSAPP_MODE: z.enum(["mock", "meta"]).default("mock"),
  WHATSAPP_APP_SECRET: z.string().min(1).optional(),
  WHATSAPP_VERIFY_TOKEN: z.string().min(1).optional(),
  WHATSAPP_ENCRYPTION_KEY: z.string().min(32).optional(),
});
function loadServerEnv(){const parsed=serverEnvSchema.safeParse({SUPABASE_SERVICE_ROLE_KEY:process.env.SUPABASE_SERVICE_ROLE_KEY,AI_PROVIDER:process.env.AI_PROVIDER,OPENAI_API_KEY:process.env.OPENAI_API_KEY,OPENAI_BASE_URL:process.env.OPENAI_BASE_URL,ANTHROPIC_API_KEY:process.env.ANTHROPIC_API_KEY,ANTHROPIC_BASE_URL:process.env.ANTHROPIC_BASE_URL,WHATSAPP_MODE:process.env.WHATSAPP_MODE,WHATSAPP_APP_SECRET:process.env.WHATSAPP_APP_SECRET,WHATSAPP_VERIFY_TOKEN:process.env.WHATSAPP_VERIFY_TOKEN,WHATSAPP_ENCRYPTION_KEY:process.env.WHATSAPP_ENCRYPTION_KEY});if(!parsed.success){throw new Error(`\n\nInvalid server environment variables:\n${parsed.error.issues.map(i=>`  - ${i.path.join(".")}: ${i.message}`).join("\n")}\n`);}return parsed.data;}
export const serverEnv=loadServerEnv();
