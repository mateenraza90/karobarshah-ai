import { z } from "zod";

/**
 * Every environment variable the app depends on is declared here.
 * If one is missing at startup, we fail immediately with a message
 * that says exactly what's missing — instead of letting a library
 * three layers down throw an opaque "invalid URL" error.
 */
const envSchema = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.url({
    error: "NEXT_PUBLIC_SUPABASE_URL must be a valid URL (see .env.example)",
  }),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(1, {
    error: "NEXT_PUBLIC_SUPABASE_ANON_KEY is required (see .env.example)",
  }),
  NEXT_PUBLIC_SITE_URL: z.url({
    error: "NEXT_PUBLIC_SITE_URL must be a valid URL (see .env.example)",
  }),
});

function loadEnv() {
  const parsed = envSchema.safeParse({
    NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
    NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL,
  });

  if (!parsed.success) {
    const issues = parsed.error.issues
      .map((issue) => `  - ${issue.path.join(".")}: ${issue.message}`)
      .join("\n");

    throw new Error(
      `\n\nInvalid or missing environment variables:\n${issues}\n\n` +
        `Copy .env.example to .env.local and fill in your Supabase project credentials.\n`,
    );
  }

  return parsed.data;
}

export const env = loadEnv();
